// script.js
const questions = [
  {
    question: "Siapa nama Aku?",
    answers: {
      1: "Darwisy",
      2: "Wisy",
      3: "babi"
    },
    correctAnswer: 1
  },
  {
    question: "Apa game fav aku?",
    answers: {
      1: "Mobile Legends",
      2: "Blue Archive",
      3: "Lost Life"
    },
    correctAnswer: 2
  },
  {
    question: "Benda apa yang aku layan?",
    answers: {
      1: "Boku no Pico",
      2: "Bokep",
      3: "Ceramah"
    },
    correctAnswer: 3
  }
];

let currentQuestionIndex = 0;
let scoreCorrect = 0;
let scoreWrong = 0;

function displayQuestion() {
  const question = questions[currentQuestionIndex];
  document.getElementById("question").textContent = question.question;
  
  const buttons = document.querySelectorAll(".answer-btn");
  buttons.forEach((btn, index) => {
    btn.textContent = question.answers[index + 1];
  });
  document.getElementById("result").textContent = "";
}

function checkAnswer(answer) {
  const correctAnswer = questions[currentQuestionIndex].correctAnswer;
  const resultText = document.getElementById("result");
  
  if (answer === correctAnswer) {
    scoreCorrect++;
    resultText.textContent = "Betul!";
    resultText.style.color = "green";
  } else {
    scoreWrong++;
    resultText.textContent = "Salah!";
    resultText.style.color = "red";
  }

  currentQuestionIndex++;

  setTimeout(() => {
    if (currentQuestionIndex < questions.length) {
      displayQuestion();
    } else {
      showResult();
    }
  }, 1000);  // Delay 1 saat
}

function showResult() {
  const result = document.getElementById("result");
  result.innerHTML = `Anda menjawab dengan <strong>betul ${scoreCorrect}</strong> dan <strong>salah ${scoreWrong}</strong>.`;
  document.querySelector(".quiz-container").style.textAlign = "center";
  document.querySelector("#quiz").style.display = "none";
}

displayQuestion();